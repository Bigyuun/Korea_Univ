%% 5.a
figure(1);
[t,y]=ode45(@pol,[0 200], [0.5; 0.5]);
plot(t,y(:,1));

title('0.5, 0.5')
figure(2);
[t,y]=ode45(@pol,[0 200], [3.5; 5]);
plot(t,y(:,1));

title('3.5, 5')
figure(3);
[t,y]=ode45(@pol,[0 200], [-3; -3]);
plot(t,y(:,1));

title('-3, -3')
figure(4);
[t,y]=ode45(@pol,[0 200], [-3; 4]);
plot(t,y(:,1));

title('-3, 4')

%% 5.b
figure(5);
[t,y]=ode45(@pol,[0 200], [0.5; 0.5]);

plot(y(:,1),y(:,2));
title('0.5, 0.5')
figure(6);
[t,y]=ode45(@pol,[0 200], [3.5; 5]);

plot(y(:,1),y(:,2));
title('3.5, 5')
figure(7);
[t,y]=ode45(@pol,[0 200], [-3; -3]);

plot(y(:,1),y(:,2));
title('-3, -3')
figure(8);
[t,y]=ode45(@pol,[0 200], [-3; 4]);

plot(y(:,1),y(:,2));
title('-3, 4')

function dydt = pol(t,x)
x1=x(1);
x2=x(2);

m=1.5;
x_dot=x2;
x_dotdot=-x1-m*x2*x1^2+m*x2;
dydt=[x_dot; x_dotdot];

end
