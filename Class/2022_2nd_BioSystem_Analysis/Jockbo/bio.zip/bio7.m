%% 7

p=0;
reward=100;
n=0;
lr=0.1;
pp=[];
ee=[];
while 1
    pp=[pp;p;];
    e = reward - p;
    ee=[ee;e;];
    if e < 1
        break
    else
        p = p + lr*e;
        n = n+1;
    end        
        
end
n
p
figure(1)
subplot(2,1,1)
plot(pp)
title('prediction')
subplot(2,1,2)
plot(ee)
title('error')