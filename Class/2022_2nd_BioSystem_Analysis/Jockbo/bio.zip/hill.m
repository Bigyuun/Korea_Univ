%% a, b
figure(1);
subplot(2,1,1)
[t, y]= ode45(@hills, [0:0.001:0.5], 0);
plot(t,y)
subplot(2,1,2)
t1=0:0.001:0.5;
y1=4950*(exp(-t1/0.034)-exp(-t1/0.0326));
plot(t1,y1)

%% c

clear all
figure(2)
hz=100;
title(hz)
[t, y] = ode45(@(t,y) teta(t,y,hz),[0:0.001:2], 0);
subplot(2,1,1)
plot(t,y)
axis([0 1 0 1500])


function dydt=hills(t,y)
Kse=136;
Kpe=75;
b=50;

A=48144*exp(-t/0.0326)-45845*exp(-t/0.034);
dydt=Kse/b*(A-(1+Kpe/Kse)*y);
end

function tetanus=teta(t,y,hz)

T=round(1000/hz);
ts=0:0.001:1;
single=max(48144*exp(-ts/0.0326)-45845*exp(-ts/0.034),0);
tw=single(1:500);
for i =0:2*hz
Ac(i*T+1:i*T+500)=tw;
end
subplot(2,1,2)
plot(Ac)
axis([0 1000 0 2500]);
Kse=136;
Kpe=75;
b=50;
 
A=Ac(round(1000*t+1));
tetanus=Kse/b*(A-(1+Kpe/Kse)*y);


end