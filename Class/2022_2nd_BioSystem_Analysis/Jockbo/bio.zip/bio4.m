%% 4. c
R1=0.039;
R2=0.9;
C=1.333;
num=[R2*C 1];
den=[C*R1*R2 R1+R2];
sys=tf(num, den);
bode(sys)