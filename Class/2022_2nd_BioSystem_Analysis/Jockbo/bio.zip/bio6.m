%% 6
clear all
V=-60;
m=am(V)/(am(V)+bm(V));
n=an(V)/(an(V)+bn(V));
h=ah(V)/(ah(V)+bh(V));
y0=[V;n;m;h];
figure(1);
II=0.02298:0.00001:0.02303;
for i=1:6
    subplot(3,2,i);
I=II(i);
[t,y]=ode45(@(t,y) HH(t,y,I), [0:0.001: 100], y0);
plot(t,y(:,1))
title(I)
axis([0 100 -80 50]);
end

figure(2)
II=0.060:0.001:0.065;

for i=1:6
    subplot(3,2,i);
I=II(i);
[t,y]=ode45(@(t,y) HH(t,y,I), [0:0.001: 100], y0);
plot(t,y(:,1))
title(I)
axis([0 100 -80 50]);
end

function dydt = HH(t,y,I)

ENa=55.17;
EK=-72.14;
El=-49.42;
gbarNa=1.2;
gbarK=0.36;
gbarl=0.003;
% I = 0.024;
Cm = 0.01;
V = y(1);
n = y(2);
m = y(3);
h = y(4);
gNa=gbarNa*m^3*h;
gK=gbarK*n^4;
gl=gbarl;
INa=gNa*(V-ENa);
IK=gK*(V-EK);
Il=gl*(V-El);
dydt = [((1/Cm)*(I-(INa+IK+Il))); an(V)*(1-n)-bn(V)*n; am(V)*(1-m)-bm(V)*m; ah(V)*(1-h)-bh(V)*h];
end
function a=am(v)
 a=0.1*(v+35)/(1-exp(-(v+35)/10));
end
function b=bm(v)
b=4.0*exp(-0.0556*(v+60));
end
function a=an(v)
a=0.01*(v+50)/(1-exp(-(v+50)/10));
end
function b=bn(v)
b=0.125*exp(-(v+60)/80);
end
function a=ah(v)
a=0.07*exp(-0.05*(v+60));
end
function b =bh(v)
b=1/(1+exp(-(0.1)*(v+30)));
end