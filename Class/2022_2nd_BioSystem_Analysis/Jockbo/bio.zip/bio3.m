%% 3.a
Fmax=45.7;

l0=6.6;
l=0:0.0001:2*l0;
Ksh=3;

figure(1);
for alpha=0:0.25:1
    Fa= alpha*Fmax*max(1-4*((l-l0)/l0).^2,0);
    plot(l,Fa);
    hold on;
end
axis([0, 2*l0, 0, 2*Fmax]);
figure(2);
for alpha=0:0.25:1
    Fp=max(Fmax/(exp(Ksh)-1)*(exp(Ksh*(l-l0)/(0.5*l0))-1), 0);    
    plot(l,Fp);
    hold on;
   
end
axis([0, 2*l0, 0, 2*Fmax]);
 figure(3);
for alpha=0:0.25:1
    Fa= alpha*Fmax*max(1-4*((l-l0)/l0).^2,0);
    Fp=max(Fmax/(exp(Ksh)-1)*(exp(Ksh*(l-l0)/(0.5*l0))-1), 0);
    plot(l,Fa+Fp);
    hold on;
end
axis([0, 2*l0, 0, 2*Fmax]);

%% 3.b
figure(4);
[t, y4] = ode45(@hill, [0:0.001: 30], [0; 0]);
plot(t, y4(:, 1));
axis([0 10 0 0.025])
function dydt= hill(t,x)

x1=x(1);
x2=x(2);
w=50;
m=12;
k=510;
b=210;
Fmax=45.7;
l0=0.066;
Ksh=3;
a1=0.8;
a2=0.5;
a3=0.43;
a4=58;
alpha=sin(w*t)^2;


x_dot=x2;
x_dotdot=((a1+a2*atan(a3-a4*x2))*(alpha*Fmax*max(1-4*((x1)/l0).^2,0)+max(Fmax/(exp(Ksh)-1)*(exp(Ksh*(-x1)/(0.5*l0))-1), 0))-k*x1-b*x2)/m;
dydt=[x_dot; x_dotdot];
end
